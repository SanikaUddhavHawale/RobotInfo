const loginForm = document.querySelector("#loginForm");
const nameInput = document.querySelector("#name");
const passwordInput = document.querySelector("#password");
const nameError = document.querySelector("#nameError");
const passwordError = document.querySelector("#passwordError");

loginForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const nameValue = nameInput.value.trim();
  const passwordValue = passwordInput.value.trim();

  if (nameValue === "") {
    nameError.textContent = "Please enter a username";
  }
  else if (nameValue.length <= 2 || nameValue.length > 20) {
    nameError.textContent = "Username length must be greater than 6";
  } 
  
  else {
    nameError.textContent = "";
  }

  if (passwordValue === "") {
    passwordError.textContent = "Please enter a password";
  }
  else if (passwordValue.length <= 5 || nameValue.length > 20) {
    passwordError.textContent = "Passwords lenght must be between  5 and 20";
  }
  else {
    passwordError.textContent = "";
  }

  if (nameValue !== "" && passwordValue !== "") {
    // Submit the form
    loginForm.submit("form.php");
  }
});
