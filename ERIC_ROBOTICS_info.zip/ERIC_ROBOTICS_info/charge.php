<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Robot Charging Status</title>
    <!-- Include Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<h1>Robot Charging Status</h1>

<!-- Canvas element to render the chart -->
<canvas id="chargingChart" width="800" height="400"></canvas>

<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "practice";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the database
$sql = "SELECT name, status FROM robot_db";
$result = $conn->query($sql);

// Initialize arrays to store robot names and charging statuses
$robotNames = [];
$statuses = [];

// Process fetched data
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $robotNames[] = $row["name"];
        $statuses[] = $row["status"];
    }
}

$conn->close();
?>

<script>
    // Retrieve data from PHP
    var robotNames = <?php echo json_encode($robotNames); ?>;
    var statuses = <?php echo json_encode($statuses); ?>;

    // Get the canvas element
    var ctx = document.getElementById('chargingChart').getContext('2d');

    // Create the chart
    var chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: robotNames, // Robot names
            datasets: [{
                label: 'Charging Status',
                data: statuses, // Charging statuses
                backgroundColor: 'rgba(75, 192, 192, 0.2)', // Bar color
                borderColor: 'rgba(75, 192, 192, 1)', // Border color
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true // Start y-axis at 0
                }
            }
        }
    });
</script>

</body>
</html>
