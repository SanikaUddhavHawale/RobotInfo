<?php
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "practice";

// Create connection
$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetching names for selection
$sql_select_names = "SELECT DISTINCT name FROM robo_history";
$result_names = $conn->query($sql_select_names);

// Fetching all records
$sql_select_all = "SELECT * FROM robo_history";
$result_all = $conn->query($sql_select_all);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fetched Data</title>
    <style>
        body {
            background-color: #000000; /* Black background */
            color: #ffffff; /* White text color */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            text-align: center;
            font-family: Arial, sans-serif;
        }
        form {
            margin-top: 20px;
        }
        select, input[type="submit"] {
            padding: 8px;
            font-size: 16px;
        }
    </style>
</head>
<body>

<div>
    <h2 style="color: white;">Select a name to view details:</h2>
    <!-- Form to select a name -->
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <select name="selected_name">
            <?php while($row_name = $result_names->fetch_assoc()): ?>
                <option value="<?php echo $row_name['name']; ?>"><?php echo $row_name['name']; ?></option>
            <?php endwhile; ?>
        </select>
        <input type="submit" value="View Details">
    </form>

    <!-- Display details of selected name -->
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $selected_name = $_POST['selected_name'];
        echo "<h3>Details for $selected_name:</h3>";
        echo "<ul>";
        while($row_all = $result_all->fetch_assoc()) {
            if ($row_all['name'] === $selected_name) {
                echo "<li>task: " . $row_all['task'] . "</li>";
                echo "<li>outcome: " . $row_all['outcome'] . "</li>";
            }
        }
        echo "</ul>";
    }
    ?>
</div>

</body>
</html>
