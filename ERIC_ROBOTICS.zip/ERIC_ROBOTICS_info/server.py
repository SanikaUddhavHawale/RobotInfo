import http.server
import socketserver

class myHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path=='/index':
            self.path='index.html'
        return http.server.SimpleHTTPRequestHandler.do_GET(self)
    

PORT = 8000
handler=myHandler

myserver=socketserver.TCPServer(("", PORT), handler)
print("Server Satrted at PORT"+str(PORT))
myserver.serve_forever()