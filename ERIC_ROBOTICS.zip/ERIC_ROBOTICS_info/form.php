<?php
      $connect=mysqli_connect("localhost","root","","jobreg");
      // if !connecdie("Connection failed");
      
      include 'login.html';

      if(isset($_POST['submit']))
      {
        $name=$_POST['name'];
        $password=$_POST['password'];
        $query="select * from jobregistration where name='$name' and password='$password'";
        $result=mysqli_query($connect,$query);
        $count=mysqli_num_rows($result);

        if($count>0){
          echo "<script>alert('login successfully')</script>";
          echo "<script>window.location='main.html'</script>";
        exit;
        }
        if($name=='admin' && $password=='ad@32'){
          echo "<script>alert('Administrator login successfully')</script>";
        }
        else{
          echo "<script>alert('login not successfully')</script>";
        }
      }
?>