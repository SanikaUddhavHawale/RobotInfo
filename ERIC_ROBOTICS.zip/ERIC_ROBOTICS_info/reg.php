<?php

$servername="localhost";
$database="jobreg";
$username="root";
$password="";
$con=mysqli_connect($servername,$username,$password,$database);

include 'index.html';
if(isset($_POST['submit']))
{
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $mobile=$_POST['mobile'];

    $sql="insert into jobregistration(name,email,password,mobile) values('$name','$email','$password','$mobile')";
    
    if(mysqli_query($con,$sql))
    {
        echo "<script>alert('new record inserted successfully')</script>";
        echo "<script>window.location='login.html'</script>";
        exit;
    }
    else{
        echo "error:".mysqli_error($con);
    }
    mysqli_close($con);
}
?>